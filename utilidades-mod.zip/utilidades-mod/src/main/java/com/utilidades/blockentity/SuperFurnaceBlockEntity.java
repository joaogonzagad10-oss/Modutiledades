package com.utilidades.blockentity;

import com.utilidades.registry.ModBlockEntities;
import com.utilidades.block.SuperFurnaceBlock;
import com.utilidades.menu.SuperFurnaceMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.crafting.SmokingRecipe;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;

/**
 * Cerebro da Fornalha Suprema.
 *
 * - 8 slots de combustivel: quando o fogo acaba, o proximo combustivel entra sozinho.
 * - 19 slots de entrada: processa um item por vez, sempre do primeiro slot ocupado para o ultimo.
 *   Quando um item termina, o proximo comeca sozinho.
 * - 19 slots de saida: os resultados vao para la.
 * - Faz o trabalho da fornalha, do alto-forno e do defumador (usa a receita mais rapida disponivel).
 */
public class SuperFurnaceBlockEntity extends BlockEntity implements MenuProvider {
    public static final int FUEL_SLOTS = 8;
    public static final int INPUT_SLOTS = 19;
    public static final int OUTPUT_SLOTS = 19;

    private boolean needsScan = true;
    private int litTime;
    private int litDuration;
    private int cookTime;
    private int cookTimeTotal;
    private int activeSlot = -1;
    private Item activeItem;
    private AbstractCookingRecipe activeRecipe;
    private float xp;

    private final ItemStackHandler fuel = new ItemStackHandler(FUEL_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            SuperFurnaceBlockEntity.this.setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            return isFuel(stack);
        }
    };

    private final ItemStackHandler input = new ItemStackHandler(INPUT_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            needsScan = true;
            SuperFurnaceBlockEntity.this.setChanged();
        }

        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            Level lvl = SuperFurnaceBlockEntity.this.level;
            return lvl != null && findRecipe(lvl, stack) != null;
        }
    };

    private final ItemStackHandler output = new ItemStackHandler(OUTPUT_SLOTS) {
        @Override
        protected void onContentsChanged(int slot) {
            needsScan = true;
            SuperFurnaceBlockEntity.this.setChanged();
        }
    };

    private final LazyOptional<IItemHandler> inputCap =
            LazyOptional.of(() -> new RestrictedHandler(input, true, false));
    private final LazyOptional<IItemHandler> outputCap =
            LazyOptional.of(() -> new RestrictedHandler(output, false, true));
    private final LazyOptional<IItemHandler> fuelCap =
            LazyOptional.of(() -> new RestrictedHandler(fuel, true, false));

    // Dados sincronizados com a tela (barra de fogo, seta, slot ativo).
    private final ContainerData dataAccess = new ContainerData() {
        @Override
        public int get(int index) {
            switch (index) {
                case 0: return scale(litTime);
                case 1: return scale(litDuration);
                case 2: return cookTime;
                case 3: return cookTimeTotal;
                case 4: return activeSlot + 1;
                default: return 0;
            }
        }

        @Override
        public void set(int index, int value) {
        }

        @Override
        public int getCount() {
            return 5;
        }
    };

    public SuperFurnaceBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SUPER_FURNACE.get(), pos, state);
    }

    private int scale(int value) {
        return litDuration > 32767 ? (int) (value * 32767L / litDuration) : value;
    }

    // ------------------------------------------------------------------ receitas / combustivel

    public static boolean isFuel(ItemStack stack) {
        return !stack.isEmpty() && ForgeHooks.getBurnTime(stack, RecipeType.SMELTING) > 0;
    }

    /** Escolhe a receita mais rapida: alto-forno, defumador, fornalha comum. */
    @Nullable
    public static AbstractCookingRecipe findRecipe(Level level, ItemStack stack) {
        if (stack.isEmpty()) {
            return null;
        }
        SimpleContainer container = new SimpleContainer(stack);
        RecipeManager manager = level.getRecipeManager();
        Optional<BlastingRecipe> blasting = manager.getRecipeFor(RecipeType.BLASTING, container, level);
        if (blasting.isPresent()) {
            return blasting.get();
        }
        Optional<SmokingRecipe> smoking = manager.getRecipeFor(RecipeType.SMOKING, container, level);
        if (smoking.isPresent()) {
            return smoking.get();
        }
        Optional<SmeltingRecipe> smelting = manager.getRecipeFor(RecipeType.SMELTING, container, level);
        return smelting.orElse(null);
    }

    private boolean canOutput(ItemStack result) {
        return !result.isEmpty() && ItemHandlerHelper.insertItem(output, result.copy(), true).isEmpty();
    }

    // ------------------------------------------------------------------ tick

    public static void serverTick(Level level, BlockPos pos, BlockState state, SuperFurnaceBlockEntity be) {
        boolean changed = false;
        boolean wasLit = be.litTime > 0;

        if (be.litTime > 0) {
            be.litTime--;
        }

        // 1) o trabalho atual ainda e valido?
        if (be.activeSlot >= 0) {
            ItemStack in = be.input.getStackInSlot(be.activeSlot);
            if (in.isEmpty() || in.getItem() != be.activeItem
                    || be.activeRecipe == null || !be.canOutput(be.activeRecipe.getResultItem())) {
                be.clearJob();
                changed = true;
            }
        }

        // 2) procura o proximo item para cozinhar (primeiro slot ocupado com receita)
        if (be.activeSlot < 0 && be.needsScan) {
            be.needsScan = false;
            for (int i = 0; i < INPUT_SLOTS; i++) {
                ItemStack in = be.input.getStackInSlot(i);
                if (in.isEmpty()) {
                    continue;
                }
                AbstractCookingRecipe recipe = findRecipe(level, in);
                if (recipe == null || !be.canOutput(recipe.getResultItem())) {
                    continue;
                }
                be.activeSlot = i;
                be.activeItem = in.getItem();
                be.activeRecipe = recipe;
                be.cookTime = 0;
                be.cookTimeTotal = Math.max(1, recipe.getCookingTime());
                changed = true;
                break;
            }
        }

        // 3) cozinha
        if (be.activeSlot >= 0) {
            if (be.litTime <= 0) {
                be.consumeFuel(level, pos);
            }
            if (be.litTime > 0) {
                be.cookTime++;
                changed = true;
                if (be.cookTime >= be.cookTimeTotal) {
                    be.finishJob();
                }
            } else if (be.cookTime > 0) {
                be.cookTime = Mth.clamp(be.cookTime - 2, 0, be.cookTimeTotal);
                changed = true;
            }
        }

        boolean isLit = be.litTime > 0;
        if (wasLit != isLit) {
            state = state.setValue(SuperFurnaceBlock.LIT, isLit);
            level.setBlock(pos, state, 3);
            changed = true;
        }
        if (changed) {
            be.setChanged();
        }
    }

    private void clearJob() {
        activeSlot = -1;
        activeItem = null;
        activeRecipe = null;
        cookTime = 0;
        needsScan = true;
    }

    private void finishJob() {
        ItemStack result = activeRecipe.getResultItem().copy();
        ItemHandlerHelper.insertItem(output, result, false);
        input.extractItem(activeSlot, 1, false);
        xp += activeRecipe.getExperience();
        clearJob();
    }

    /** Puxa o proximo combustivel dos 8 slots (primeiro ocupado). */
    private void consumeFuel(Level level, BlockPos pos) {
        for (int i = 0; i < FUEL_SLOTS; i++) {
            ItemStack stack = fuel.getStackInSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            int burn = ForgeHooks.getBurnTime(stack, RecipeType.SMELTING);
            if (burn <= 0) {
                continue;
            }
            ItemStack remainder = stack.getContainerItem(); // balde vazio do balde de lava, por exemplo
            fuel.extractItem(i, 1, false);
            litTime = burn;
            litDuration = burn;
            if (!remainder.isEmpty()) {
                ItemStack left = ItemHandlerHelper.insertItem(output, remainder, false);
                if (!left.isEmpty()) {
                    Containers.dropItemStack(level, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, left);
                }
            }
            return;
        }
    }

    // ------------------------------------------------------------------ xp

    /** Entrega a experiencia acumulada ao jogador que abriu a fornalha. */
    public void releaseXp(ServerPlayer player) {
        giveXp((ServerLevel) player.level, player.position());
    }

    private void giveXp(ServerLevel level, Vec3 where) {
        int whole = Mth.floor(xp);
        float fraction = xp - whole;
        if (fraction > 0.0F && Math.random() < fraction) {
            whole++;
        }
        xp = 0.0F;
        if (whole > 0) {
            ExperienceOrb.award(level, where, whole);
        }
        setChanged();
    }

    // ------------------------------------------------------------------ quebrar o bloco

    public void dropContents(Level level, BlockPos pos) {
        ItemStackHandler[] all = {fuel, input, output};
        for (ItemStackHandler handler : all) {
            for (int i = 0; i < handler.getSlots(); i++) {
                ItemStack stack = handler.getStackInSlot(i);
                if (!stack.isEmpty()) {
                    Containers.dropItemStack(level, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, stack.copy());
                }
            }
        }
        if (level instanceof ServerLevel serverLevel) {
            giveXp(serverLevel, Vec3.atCenterOf(pos));
        }
    }

    // ------------------------------------------------------------------ menu

    @Override
    public Component getDisplayName() {
        return new TranslatableComponent("block.utilidades.super_furnace");
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
        return new SuperFurnaceMenu(id, inventory, fuel, input, output, dataAccess,
                ContainerLevelAccess.create(level, getBlockPos()));
    }

    // ------------------------------------------------------------------ nbt

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Fuel", fuel.serializeNBT());
        tag.put("Input", input.serializeNBT());
        tag.put("Output", output.serializeNBT());
        tag.putInt("LitTime", litTime);
        tag.putInt("LitDuration", litDuration);
        tag.putFloat("Xp", xp);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        fuel.deserializeNBT(tag.getCompound("Fuel"));
        input.deserializeNBT(tag.getCompound("Input"));
        output.deserializeNBT(tag.getCompound("Output"));
        litTime = tag.getInt("LitTime");
        litDuration = tag.getInt("LitDuration");
        xp = tag.getFloat("Xp");
        needsScan = true;
    }

    // ------------------------------------------------------------------ automacao (funil, etc.)

    @Nonnull
    @Override
    public <T> LazyOptional<T> getCapability(@Nonnull Capability<T> cap, @Nullable Direction side) {
        if (!remove && cap == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            if (side == Direction.DOWN) {
                return outputCap.cast();
            }
            if (side == null || side == Direction.UP) {
                return inputCap.cast();
            }
            return fuelCap.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        inputCap.invalidate();
        outputCap.invalidate();
        fuelCap.invalidate();
    }

    /** Deixa funil colocar so em cima (entrada) e nas laterais (combustivel), e tirar so por baixo (saida). */
    private static class RestrictedHandler implements IItemHandler {
        private final IItemHandler inner;
        private final boolean canInsert;
        private final boolean canExtract;

        RestrictedHandler(IItemHandler inner, boolean canInsert, boolean canExtract) {
            this.inner = inner;
            this.canInsert = canInsert;
            this.canExtract = canExtract;
        }

        @Override
        public int getSlots() {
            return inner.getSlots();
        }

        @Nonnull
        @Override
        public ItemStack getStackInSlot(int slot) {
            return inner.getStackInSlot(slot);
        }

        @Nonnull
        @Override
        public ItemStack insertItem(int slot, @Nonnull ItemStack stack, boolean simulate) {
            return canInsert ? inner.insertItem(slot, stack, simulate) : stack;
        }

        @Nonnull
        @Override
        public ItemStack extractItem(int slot, int amount, boolean simulate) {
            return canExtract ? inner.extractItem(slot, amount, simulate) : ItemStack.EMPTY;
        }

        @Override
        public int getSlotLimit(int slot) {
            return inner.getSlotLimit(slot);
        }

        @Override
        public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
            return canInsert && inner.isItemValid(slot, stack);
        }
    }
}
