package com.utilidades.item;

import com.utilidades.block.LightSourceBlock;
import com.utilidades.registry.ModBlocks;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Capacete que ilumina como uma tocha (luz nivel 14) onde o jogador anda.
 * Coloca um bloco de luz invisivel no pe/cabeca do jogador; o bloco se remove sozinho.
 */
public class LightHelmetItem extends ArmorItem {

    public LightHelmetItem(ArmorMaterial material, EquipmentSlot slot, Properties properties) {
        super(material, slot, properties);
    }

    public static boolean isWearing(LivingEntity entity) {
        return entity.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof LightHelmetItem;
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (level.isClientSide || player.isSpectator()) {
            return;
        }
        BlockPos feet = player.blockPosition();
        BlockPos head = feet.above();
        if (LightSourceBlock.isLight(level, feet) || LightSourceBlock.isLight(level, head)) {
            return; // ja tem luz aqui
        }
        if (!tryPlaceLight(level, feet)) {
            tryPlaceLight(level, head);
        }
    }

    private static boolean tryPlaceLight(Level level, BlockPos pos) {
        BlockState current = level.getBlockState(pos);
        BlockState light = ModBlocks.LIGHT_SOURCE.get().defaultBlockState();
        if (current.isAir()) {
            level.setBlock(pos, light, 3);
            return true;
        }
        // dentro d'agua (lagos de caverna)
        if (current.is(Blocks.WATER) && current.getFluidState().isSource()) {
            level.setBlock(pos, light.setValue(LightSourceBlock.WATERLOGGED, true), 3);
            return true;
        }
        return false;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(new TranslatableComponent("tooltip.utilidades.helmet").withStyle(ChatFormatting.GRAY));
    }
}
