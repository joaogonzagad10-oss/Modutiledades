package com.utilidades.item;

import com.utilidades.menu.BagMenu;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;

/** Inventario de 14 slots guardado dentro do NBT da propria bolsa. */
public class BagContainer extends SimpleContainer {
    public static final String KEY = "BagItems";

    private final ItemStack bag;
    private boolean loading;

    public BagContainer(ItemStack bag) {
        super(BagMenu.BAG_SLOTS);
        this.bag = bag;
        this.loading = true;
        CompoundTag tag = bag.getTag();
        if (tag != null && tag.contains(KEY, Tag.TAG_LIST)) {
            ListTag list = tag.getList(KEY, Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size(); i++) {
                CompoundTag entry = list.getCompound(i);
                int slot = entry.getByte("Slot") & 255;
                if (slot < getContainerSize()) {
                    setItem(slot, ItemStack.of(entry));
                }
            }
        }
        this.loading = false;
    }

    @Override
    public void setChanged() {
        super.setChanged();
        if (!loading) {
            save();
        }
    }

    private void save() {
        ListTag list = new ListTag();
        for (int i = 0; i < getContainerSize(); i++) {
            ItemStack stack = getItem(i);
            if (!stack.isEmpty()) {
                CompoundTag entry = new CompoundTag();
                entry.putByte("Slot", (byte) i);
                stack.save(entry);
                list.add(entry);
            }
        }
        if (list.isEmpty()) {
            if (bag.hasTag()) {
                bag.getTag().remove(KEY);
            }
        } else {
            bag.getOrCreateTag().put(KEY, list);
        }
    }
}
