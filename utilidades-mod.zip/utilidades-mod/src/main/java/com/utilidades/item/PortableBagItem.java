package com.utilidades.item;

import com.utilidades.menu.BagMenu;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Bolsa portatil com 14 slots.
 * - Botao direito com ela na mao abre.
 * - Botao direito EM CIMA dela no inventario (com o cursor vazio) tambem abre.
 */
public class PortableBagItem extends Item {

    public PortableBagItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            int index = hand == InteractionHand.MAIN_HAND ? player.getInventory().selected : 40; // 40 = mao secundaria
            openBag(serverPlayer, index);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Chamado quando o jogador clica neste item dentro de uma tela de inventario. */
    @Override
    public boolean overrideStackedOnOther(ItemStack stack, Slot slot, ClickAction action, Player player) {
        if (action != ClickAction.SECONDARY) {
            return false;
        }
        if (!player.containerMenu.getCarried().isEmpty()) {
            return false; // com item no cursor, segue o comportamento normal
        }
        if (slot.container != player.getInventory()) {
            return false; // so funciona na bolsa que esta no seu proprio inventario
        }
        if (player instanceof ServerPlayer serverPlayer) {
            openBag(serverPlayer, slot.getContainerSlot());
        }
        return true;
    }

    public static void openBag(ServerPlayer player, int inventoryIndex) {
        ItemStack bag = player.getInventory().getItem(inventoryIndex);
        if (!(bag.getItem() instanceof PortableBagItem)) {
            return;
        }
        NetworkHooks.openGui(player,
                new SimpleMenuProvider((id, inv, p) -> new BagMenu(id, inv, inventoryIndex, new BagContainer(bag)),
                        bag.getHoverName()),
                buf -> buf.writeVarInt(inventoryIndex));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int used = 0;
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains(BagContainer.KEY, Tag.TAG_LIST)) {
            used = tag.getList(BagContainer.KEY, Tag.TAG_COMPOUND).size();
        }
        tooltip.add(new TranslatableComponent("tooltip.utilidades.bag_items", used, BagMenu.BAG_SLOTS)
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(new TranslatableComponent("tooltip.utilidades.bag_hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
