package com.utilidades.menu;

import com.utilidades.item.PortableBagItem;
import com.utilidades.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class BagMenu extends AbstractContainerMenu {
    public static final int BAG_SLOTS = 14;
    public static final int COLUMNS = 7;
    public static final int WIDTH = 176;
    public static final int HEIGHT = 150;

    private final Container bag;
    private final int bagInventoryIndex;

    /** Cliente. */
    public BagMenu(int id, Inventory inventory, FriendlyByteBuf buf) {
        this(id, inventory, buf.readVarInt(), new SimpleContainer(BAG_SLOTS));
    }

    /** Servidor (ou cliente com container vazio, que o servidor preenche). */
    public BagMenu(int id, Inventory inventory, int bagInventoryIndex, Container bag) {
        super(ModMenus.BAG.get(), id);
        checkContainerSize(bag, BAG_SLOTS);
        this.bag = bag;
        this.bagInventoryIndex = bagInventoryIndex;
        bag.startOpen(inventory.player);

        // 14 slots: 2 fileiras de 7, centralizadas
        for (int i = 0; i < BAG_SLOTS; i++) {
            addSlot(new BagSlot(bag, i, 25 + (i % COLUMNS) * 18, 18 + (i / COLUMNS) * 18));
        }

        // inventario do jogador (a propria bolsa fica travada)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int index = col + row * 9 + 9;
                addSlot(createPlayerSlot(inventory, index, 8 + col * 18, 67 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(createPlayerSlot(inventory, col, 8 + col * 18, 125));
        }
    }

    private Slot createPlayerSlot(Inventory inventory, int index, int x, int y) {
        return index == bagInventoryIndex ? new LockedSlot(inventory, index, x, y) : new Slot(inventory, index, x, y);
    }

    @Override
    public boolean stillValid(Player player) {
        return player.getInventory().getItem(bagInventoryIndex).getItem() instanceof PortableBagItem;
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        bag.stopOpen(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < BAG_SLOTS) {
                if (!moveItemStackTo(stack, BAG_SLOTS, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (!moveItemStackTo(stack, 0, BAG_SLOTS, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return result;
    }

    /** Slot da bolsa: nao aceita outra bolsa dentro. */
    private static class BagSlot extends Slot {
        BagSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return !(stack.getItem() instanceof PortableBagItem);
        }
    }

    /** Slot do inventario que guarda a bolsa aberta: nao pode ser mexido enquanto ela esta aberta. */
    public static class LockedSlot extends Slot {
        LockedSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPickup(Player player) {
            return false;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }
}
