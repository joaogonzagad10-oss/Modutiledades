package com.utilidades.menu;

import com.utilidades.blockentity.SuperFurnaceBlockEntity;
import com.utilidades.registry.ModBlocks;
import com.utilidades.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;

import javax.annotation.Nonnull;

public class SuperFurnaceMenu extends AbstractContainerMenu {
    // Tamanho da tela
    public static final int WIDTH = 244;
    public static final int HEIGHT = 216;

    // Intervalos dos slots no menu
    public static final int FUEL_START = 0;
    public static final int FUEL_END = FUEL_START + SuperFurnaceBlockEntity.FUEL_SLOTS;          // 8
    public static final int INPUT_START = FUEL_END;                                              // 8
    public static final int INPUT_END = INPUT_START + SuperFurnaceBlockEntity.INPUT_SLOTS;       // 27
    public static final int OUTPUT_START = INPUT_END;                                            // 27
    public static final int OUTPUT_END = OUTPUT_START + SuperFurnaceBlockEntity.OUTPUT_SLOTS;    // 46
    public static final int PLAYER_START = OUTPUT_END;                                           // 46
    public static final int PLAYER_END = PLAYER_START + 36;                                      // 82

    // Posicoes (relativas ao canto da tela)
    public static int fuelX(int i) { return 8 + (i % 2) * 18; }
    public static int fuelY(int i) { return 20 + (i / 2) * 18; }
    public static int inputX(int i) { return 56 + (i < 10 ? i : i - 10) * 18; }
    public static int inputY(int i) { return 20 + (i < 10 ? 0 : 18); }
    public static int outputX(int i) { return inputX(i); }
    public static int outputY(int i) { return 84 + (i < 10 ? 0 : 18); }

    private final ContainerLevelAccess access;
    private final ContainerData data;
    private final Level level;

    /** Cliente: os dados reais chegam do servidor. */
    public SuperFurnaceMenu(int id, Inventory inventory, FriendlyByteBuf buf) {
        this(id, inventory,
                new ItemStackHandler(SuperFurnaceBlockEntity.FUEL_SLOTS),
                new ItemStackHandler(SuperFurnaceBlockEntity.INPUT_SLOTS),
                new ItemStackHandler(SuperFurnaceBlockEntity.OUTPUT_SLOTS),
                new SimpleContainerData(5),
                ContainerLevelAccess.NULL);
    }

    /** Servidor. */
    public SuperFurnaceMenu(int id, Inventory inventory, IItemHandler fuel, IItemHandler input,
                            IItemHandler output, ContainerData data, ContainerLevelAccess access) {
        super(ModMenus.SUPER_FURNACE.get(), id);
        this.access = access;
        this.data = data;
        this.level = inventory.player.level;

        for (int i = 0; i < SuperFurnaceBlockEntity.FUEL_SLOTS; i++) {
            addSlot(new FuelSlot(fuel, i, fuelX(i), fuelY(i)));
        }
        for (int i = 0; i < SuperFurnaceBlockEntity.INPUT_SLOTS; i++) {
            addSlot(new InputSlot(input, i, inputX(i), inputY(i), level));
        }
        for (int i = 0; i < SuperFurnaceBlockEntity.OUTPUT_SLOTS; i++) {
            addSlot(new OutputSlot(output, i, outputX(i), outputY(i)));
        }

        int invX = 42;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, invX + col * 18, 134 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, invX + col * 18, 192));
        }

        addDataSlots(data);
    }

    // ---- dados para a tela
    public boolean isLit() {
        return data.get(0) > 0;
    }

    public float litFraction() {
        int total = data.get(1);
        return total <= 0 ? 0.0F : Mth.clamp(data.get(0) / (float) total, 0.0F, 1.0F);
    }

    public float cookFraction() {
        int total = data.get(3);
        return total <= 0 ? 0.0F : Mth.clamp(data.get(2) / (float) total, 0.0F, 1.0F);
    }

    /** Indice (0-18) do slot de entrada que esta cozinhando, ou -1. */
    public int activeInputSlot() {
        return data.get(4) - 1;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, ModBlocks.SUPER_FURNACE.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();

            if (index >= OUTPUT_START && index < OUTPUT_END) {
                if (!moveItemStackTo(stack, PLAYER_START, PLAYER_END, true)) {
                    return ItemStack.EMPTY;
                }
            } else if (index >= PLAYER_START) {
                boolean moved = false;
                if (SuperFurnaceBlockEntity.findRecipe(level, stack) != null) {
                    moved = moveItemStackTo(stack, INPUT_START, INPUT_END, false);
                }
                if (!moved && SuperFurnaceBlockEntity.isFuel(stack)) {
                    moved = moveItemStackTo(stack, FUEL_START, FUEL_END, false);
                }
                if (!moved) {
                    return ItemStack.EMPTY;
                }
            } else {
                if (!moveItemStackTo(stack, PLAYER_START, PLAYER_END, false)) {
                    return ItemStack.EMPTY;
                }
            }

            if (stack.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == result.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, stack);
        }
        return result;
    }

    // ---- slots especiais

    private static class FuelSlot extends SlotItemHandler {
        FuelSlot(IItemHandler handler, int index, int x, int y) {
            super(handler, index, x, y);
        }

        @Override
        public boolean mayPlace(@Nonnull ItemStack stack) {
            return SuperFurnaceBlockEntity.isFuel(stack) && super.mayPlace(stack);
        }
    }

    private static class InputSlot extends SlotItemHandler {
        private final Level level;

        InputSlot(IItemHandler handler, int index, int x, int y, Level level) {
            super(handler, index, x, y);
            this.level = level;
        }

        @Override
        public boolean mayPlace(@Nonnull ItemStack stack) {
            return SuperFurnaceBlockEntity.findRecipe(level, stack) != null && super.mayPlace(stack);
        }
    }

    private static class OutputSlot extends SlotItemHandler {
        OutputSlot(IItemHandler handler, int index, int x, int y) {
            super(handler, index, x, y);
        }

        @Override
        public boolean mayPlace(@Nonnull ItemStack stack) {
            return false;
        }
    }
}
