package com.utilidades;

import com.utilidades.registry.ModBlockEntities;
import com.utilidades.registry.ModBlocks;
import com.utilidades.registry.ModItems;
import com.utilidades.registry.ModMenus;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(UtilidadesMod.MODID)
public class UtilidadesMod {
    public static final String MODID = "utilidades";

    public UtilidadesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModMenus.MENUS.register(bus);
    }
}
