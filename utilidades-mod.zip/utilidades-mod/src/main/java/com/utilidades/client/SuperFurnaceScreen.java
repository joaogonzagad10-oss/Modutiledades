package com.utilidades.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.utilidades.blockentity.SuperFurnaceBlockEntity;
import com.utilidades.menu.SuperFurnaceMenu;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class SuperFurnaceScreen extends AbstractContainerScreen<SuperFurnaceMenu> {

    // chama 11x14 (cada # e um pixel)
    private static final String[] FLAME = {
            "....#......",
            "....##.....",
            "...###..#..",
            "...####.##.",
            "..#########",
            ".##########",
            ".##########",
            "###########",
            "###########",
            "###########",
            ".#########.",
            ".#########.",
            "..#######..",
            "...#####..."
    };

    private static final int FLAME_X = 20;
    private static final int FLAME_Y = 96;
    private static final int ARROW_X = 138;
    private static final int ARROW_Y = 60;
    private static final int ARROW_SHAFT_ROWS = 12;
    private static final int ARROW_ROWS = 20;

    public SuperFurnaceScreen(SuperFurnaceMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = SuperFurnaceMenu.WIDTH;
        this.imageHeight = SuperFurnaceMenu.HEIGHT;
        this.inventoryLabelX = 42;
        this.inventoryLabelY = 123;
    }

    @Override
    public void render(PoseStack ps, int mouseX, int mouseY, float partialTick) {
        renderBackground(ps);
        super.render(ps, mouseX, mouseY, partialTick);
        renderTooltip(ps, mouseX, mouseY);
    }

    @Override
    protected void renderBg(PoseStack ps, float partialTick, int mouseX, int mouseY) {
        GuiHelper.panel(ps, leftPos, topPos, imageWidth, imageHeight);

        int active = menu.activeInputSlot();
        for (int i = 0; i < menu.slots.size(); i++) {
            Slot slot = menu.slots.get(i);
            int sx = leftPos + slot.x - 1;
            int sy = topPos + slot.y - 1;
            boolean output = i >= SuperFurnaceMenu.OUTPUT_START && i < SuperFurnaceMenu.OUTPUT_END;
            boolean fuel = i >= SuperFurnaceMenu.FUEL_START && i < SuperFurnaceMenu.FUEL_END;
            int fill = output ? 0xFF7E9A7E : fuel ? 0xFF9A8470 : 0xFF8B8B8B;
            if (i >= SuperFurnaceMenu.PLAYER_START) {
                fill = 0xFF8B8B8B;
            }
            GuiHelper.slot(ps, sx, sy, fill);
        }

        // destaca o slot de entrada que esta sendo cozinhado agora
        if (active >= 0 && active < SuperFurnaceBlockEntity.INPUT_SLOTS) {
            Slot slot = menu.slots.get(SuperFurnaceMenu.INPUT_START + active);
            GuiHelper.outline(ps, leftPos + slot.x - 1, topPos + slot.y - 1, 0xFFFFA020);
        }

        drawFlame(ps, leftPos + FLAME_X, topPos + FLAME_Y, menu.litFraction());
        drawArrow(ps, leftPos + ARROW_X, topPos + ARROW_Y, menu.cookFraction());
    }

    @Override
    protected void renderLabels(PoseStack ps, int mouseX, int mouseY) {
        super.renderLabels(ps, mouseX, mouseY);
        Component in = new TranslatableComponent("gui.utilidades.input");
        Component out = new TranslatableComponent("gui.utilidades.output");
        font.draw(ps, in, 58.0F, 66.0F, 0x404040);
        font.draw(ps, out, (float) (236 - font.width(out)), 66.0F, 0x404040);
    }

    private void drawFlame(PoseStack ps, int x, int y, float fraction) {
        int rows = FLAME.length;
        int litRows = Math.round(fraction * rows);
        if (fraction > 0.0F && litRows == 0) {
            litRows = 1;
        }
        for (int r = 0; r < rows; r++) {
            boolean lit = r >= rows - litRows;
            int color = !lit ? 0xFF5A5A5A : (r > rows / 2 ? 0xFFFFD23A : 0xFFFF8A00);
            String line = FLAME[r];
            for (int c = 0; c < line.length(); c++) {
                if (line.charAt(c) == '#') {
                    GuiComponent.fill(ps, x + c, y + r, x + c + 1, y + r + 1, color);
                }
            }
        }
    }

    /** Seta apontando para baixo (entrada em cima, saida embaixo). */
    private void drawArrow(PoseStack ps, int x, int y, float progress) {
        int filledRows = Math.round(progress * ARROW_ROWS);
        for (int r = 0; r < ARROW_ROWS; r++) {
            int x1;
            int x2;
            if (r < ARROW_SHAFT_ROWS) {
                x1 = 6;
                x2 = 10;
            } else {
                int k = r - ARROW_SHAFT_ROWS;
                x1 = k;
                x2 = 16 - k;
            }
            int color = r < filledRows ? 0xFFFFA020 : 0xFF6B6B6B;
            GuiComponent.fill(ps, x + x1, y + r, x + x2, y + r + 1, color);
        }
    }
}
