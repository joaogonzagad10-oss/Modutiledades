package com.utilidades.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.utilidades.menu.BagMenu;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class BagScreen extends AbstractContainerScreen<BagMenu> {

    public BagScreen(BagMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = BagMenu.WIDTH;
        this.imageHeight = BagMenu.HEIGHT;
        this.inventoryLabelY = BagMenu.HEIGHT - 94;
    }

    @Override
    public void render(PoseStack ps, int mouseX, int mouseY, float partialTick) {
        renderBackground(ps);
        super.render(ps, mouseX, mouseY, partialTick);
        renderTooltip(ps, mouseX, mouseY);
    }

    @Override
    protected void renderBg(PoseStack ps, float partialTick, int mouseX, int mouseY) {
        GuiHelper.panel(ps, leftPos, topPos, imageWidth, imageHeight);
        for (Slot slot : menu.slots) {
            boolean locked = slot instanceof BagMenu.LockedSlot;
            GuiHelper.slot(ps, leftPos + slot.x - 1, topPos + slot.y - 1, locked ? 0xFF7A5A3A : 0xFF8B8B8B);
        }
    }
}
