package com.utilidades.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiComponent;

/** Desenha paineis e slots no estilo do Minecraft sem precisar de textura de GUI. */
public final class GuiHelper {
    private GuiHelper() {
    }

    public static void panel(PoseStack ps, int x, int y, int w, int h) {
        GuiComponent.fill(ps, x, y, x + w, y + h, 0xFF000000);
        GuiComponent.fill(ps, x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        GuiComponent.fill(ps, x + 1, y + 1, x + w - 2, y + 3, 0xFFFFFFFF);
        GuiComponent.fill(ps, x + 1, y + 1, x + 3, y + h - 2, 0xFFFFFFFF);
        GuiComponent.fill(ps, x + 2, y + h - 3, x + w - 1, y + h - 1, 0xFF555555);
        GuiComponent.fill(ps, x + w - 3, y + 2, x + w - 1, y + h - 1, 0xFF555555);
    }

    /** Moldura de slot 18x18, com o canto em (x, y). */
    public static void slot(PoseStack ps, int x, int y) {
        slot(ps, x, y, 0xFF8B8B8B);
    }

    public static void slot(PoseStack ps, int x, int y, int fill) {
        GuiComponent.fill(ps, x, y, x + 18, y + 18, fill);
        GuiComponent.fill(ps, x, y, x + 17, y + 1, 0xFF373737);
        GuiComponent.fill(ps, x, y, x + 1, y + 17, 0xFF373737);
        GuiComponent.fill(ps, x + 1, y + 17, x + 18, y + 18, 0xFFFFFFFF);
        GuiComponent.fill(ps, x + 17, y + 1, x + 18, y + 18, 0xFFFFFFFF);
    }

    /** Contorno de 1px ao redor de um slot (usado para destacar o item que esta cozinhando). */
    public static void outline(PoseStack ps, int x, int y, int color) {
        GuiComponent.fill(ps, x - 1, y - 1, x + 19, y, color);
        GuiComponent.fill(ps, x - 1, y + 18, x + 19, y + 19, color);
        GuiComponent.fill(ps, x - 1, y, x, y + 18, color);
        GuiComponent.fill(ps, x + 18, y, x + 19, y + 18, color);
    }
}
