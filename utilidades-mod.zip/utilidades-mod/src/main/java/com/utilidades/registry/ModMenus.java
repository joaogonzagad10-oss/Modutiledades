package com.utilidades.registry;

import com.utilidades.UtilidadesMod;
import com.utilidades.menu.BagMenu;
import com.utilidades.menu.SuperFurnaceMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.CONTAINERS, UtilidadesMod.MODID);

    public static final RegistryObject<MenuType<SuperFurnaceMenu>> SUPER_FURNACE =
            MENUS.register("super_furnace", () -> IForgeMenuType.create(SuperFurnaceMenu::new));

    public static final RegistryObject<MenuType<BagMenu>> BAG =
            MENUS.register("bag", () -> IForgeMenuType.create(BagMenu::new));
}
