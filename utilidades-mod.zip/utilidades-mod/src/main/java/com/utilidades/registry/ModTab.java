package com.utilidades.registry;

import com.utilidades.UtilidadesMod;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public class ModTab {
    public static final CreativeModeTab TAB = new CreativeModeTab(UtilidadesMod.MODID) {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ModItems.SUPER_FURNACE.get());
        }
    };
}
