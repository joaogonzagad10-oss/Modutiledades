package com.utilidades.registry;

import com.utilidades.UtilidadesMod;
import com.utilidades.block.LightSourceBlock;
import com.utilidades.block.SuperFurnaceBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, UtilidadesMod.MODID);

    public static final RegistryObject<Block> SUPER_FURNACE = BLOCKS.register("super_furnace",
            () -> new SuperFurnaceBlock(BlockBehaviour.Properties.of(Material.STONE)
                    .strength(3.5F)
                    .requiresCorrectToolForDrops()
                    .lightLevel(state -> state.getValue(SuperFurnaceBlock.LIT) ? 13 : 0)));

    // Bloco invisivel de luz usado pelo capacete (nao tem item).
    public static final RegistryObject<Block> LIGHT_SOURCE = BLOCKS.register("light_source",
            () -> new LightSourceBlock(BlockBehaviour.Properties.of(Material.AIR)
                    .noCollission()
                    .noOcclusion()
                    .noDrops()
                    .lightLevel(state -> 14)));
}
