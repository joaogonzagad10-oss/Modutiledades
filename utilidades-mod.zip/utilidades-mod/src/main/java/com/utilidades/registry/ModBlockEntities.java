package com.utilidades.registry;

import com.utilidades.UtilidadesMod;
import com.utilidades.blockentity.SuperFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITIES, UtilidadesMod.MODID);

    public static final RegistryObject<BlockEntityType<SuperFurnaceBlockEntity>> SUPER_FURNACE =
            BLOCK_ENTITIES.register("super_furnace",
                    () -> BlockEntityType.Builder.of(SuperFurnaceBlockEntity::new,
                            ModBlocks.SUPER_FURNACE.get()).build(null));
}
