package com.utilidades.registry;

import com.utilidades.UtilidadesMod;
import com.utilidades.item.LightHelmetItem;
import com.utilidades.item.ModArmorMaterial;
import com.utilidades.item.PortableBagItem;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, UtilidadesMod.MODID);

    public static final RegistryObject<Item> SUPER_FURNACE = ITEMS.register("super_furnace",
            () -> new BlockItem(ModBlocks.SUPER_FURNACE.get(), new Item.Properties().tab(ModTab.TAB)));

    public static final RegistryObject<Item> PORTABLE_BAG = ITEMS.register("portable_bag",
            () -> new PortableBagItem(new Item.Properties().tab(ModTab.TAB).stacksTo(1)));

    public static final RegistryObject<Item> LIGHT_HELMET = ITEMS.register("light_helmet",
            () -> new LightHelmetItem(ModArmorMaterial.LAMP, EquipmentSlot.HEAD,
                    new Item.Properties().tab(ModTab.TAB)));
}
