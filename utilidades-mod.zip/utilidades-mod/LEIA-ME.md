# Utilidades Supremas (Forge 1.18.2)

Três itens: **Fornalha Suprema**, **Bolsa Portátil** e **Capacete de Iluminação**.

## Como compilar

1. Copie do projeto do mod de baús para esta pasta: `gradlew`, `gradlew.bat` e a pasta `gradle/`.
2. Abra um terminal aqui e rode: `gradlew build`
3. O mod fica em `build/libs/utilidades-1.0.0.jar`. Coloque na pasta `mods` do Minecraft 1.18.2 com Forge.

Para testar direto: `gradlew runClient`.

## Receitas

- **Fornalha Suprema:** 4 barras de ferro (cantos), 1 barra de ouro (cima, meio), alto-forno + fornalha + defumador (linha do meio), funil (baixo, meio).
- **Bolsa Portátil:** 2 barbantes (cima, nas pontas), 6 couros, 1 baú (meio).
- **Capacete de Iluminação:** 5 barras de ouro + 1 lanterna (a lanterna fica no meio da fileira de baixo).

## Como funciona

**Fornalha Suprema** (botão direito para abrir)
- 8 slots de combustível (esquerda). Quando o fogo acaba, o próximo combustível entra sozinho. Balde de lava devolve o balde vazio para os slots de saída.
- 19 slots de entrada (em cima). Cozinha um item por vez, do primeiro slot ocupado ao último. Quando um item termina, o próximo começa sozinho. O slot que está cozinhando fica com contorno laranja.
- 19 slots de saída (embaixo). Só dá para retirar.
- Faz o trabalho da fornalha, do alto-forno e do defumador: usa a receita mais rápida que existir para o item.
- A experiência fica guardada e é entregue quando você abre a fornalha (ou cai no chão se você quebrar o bloco).
- Funil: por cima coloca na entrada, pelas laterais coloca combustível, por baixo retira da saída.

**Bolsa Portátil** (14 slots)
- Botão direito com a bolsa na mão abre.
- Botão direito em cima dela dentro do inventário também abre (com o cursor vazio). No modo criativo, use a bolsa na mão.
- Não dá para guardar uma bolsa dentro de outra. Shulker box pode.

**Capacete de Iluminação**
- Ilumina com a mesma força de uma tocha (nível 14) por onde você anda, inclusive dentro d'água.
- A luz é um bloco invisível que se apaga sozinho assim que você sai de perto.
- Defesa 3, durabilidade igual à de diamante, encantamento alto como o ouro. Os números estão em `ModArmorMaterial.java`.

## Texturas

As texturas são pixel art geradas pelo script `tools/gen_resources.py`. Para trocar por outras, é só substituir os PNGs em `src/main/resources/assets/utilidades/textures/`. O capacete usa o modelo padrão de capacete; um modelo 3D totalmente novo precisa ser feito no Blockbench.
