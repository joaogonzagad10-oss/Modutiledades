#!/usr/bin/env python3
"""Gera texturas (pixel art) e JSONs do mod. Uso: python3 tools/gen_resources.py [preview.png]"""
import json
import os
import random
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "src", "main", "resources"))
MOD = "utilidades"
ASSETS = os.path.join(ROOT, "assets", MOD)
DATA = os.path.join(ROOT, "data", MOD)


# ----------------------------------------------------------------- helpers
def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def hexc(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def rect(img, x0, y0, w, h, c):
    for y in range(y0, y0 + h):
        for x in range(x0, x0 + w):
            img.putpixel((x, y), c)


def from_halves(rows, pal, rshade=None):
    """Cada linha tem so a metade esquerda (8 chars); a direita e espelhada (com sombra)."""
    rshade = rshade or {}
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, left in enumerate(rows):
        assert len(left) == 8, (y, left)
        row = list(left) + [rshade.get(left[7 - j], left[7 - j]) for j in range(8)]
        for x, ch in enumerate(row):
            if ch != ".":
                img.putpixel((x, y), pal[ch])
    return img


# ----------------------------------------------------------------- texturas de bloco
GOLD = hexc("#C8962A")
GOLD_L = hexc("#FFD65A")
GOLD_D = hexc("#8C6414")
DARK = hexc("#1A1A22")
SLIT = hexc("#14141C")


def stone(rng):
    img = Image.new("RGBA", (16, 16))
    for y in range(16):
        for x in range(16):
            d = rng.randint(-7, 7)
            img.putpixel((x, y), (58 + d, 61 + d, 76 + d, 255))
    return img


def frame(img):
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), DARK)
    for i in range(1, 15):
        for (x, y) in ((i, 1), (i, 14), (1, i), (14, i)):
            img.putpixel((x, y), GOLD)
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14)):
        img.putpixel((x, y), GOLD_L)


def tex_side():
    img = stone(random.Random(1))
    frame(img)
    for y in (5, 7, 9, 11):
        for x in range(4, 12):
            img.putpixel((x, y), SLIT)
    for y in (6, 8, 10):
        for x in range(4, 12):
            r, g, b, a = img.getpixel((x, y))
            img.putpixel((x, y), (r + 10, g + 10, b + 14, 255))
    return img


def tex_top():
    img = stone(random.Random(2))
    frame(img)
    cx, cy = 7.5, 7.5
    for y in range(16):
        for x in range(16):
            d = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            if d <= 3.2:
                img.putpixel((x, y), hexc("#22242E"))
            elif d <= 4.6:
                img.putpixel((x, y), GOLD_L if (x + y) % 3 else GOLD)
    for (x, y) in ((7, 7), (8, 7), (7, 8), (8, 8)):
        img.putpixel((x, y), hexc("#59E6FF"))
    return img


LIGHTS = [((3, 2), hexc("#E03C34")), ((7, 2), hexc("#46DCFF")), ((11, 2), hexc("#FFA028"))]


def front_common(img):
    frame(img)
    for (lx, ly), col in LIGHTS:
        rect(img, lx, ly, 2, 2, col)
    for x in range(2, 14):
        img.putpixel((x, 4), SLIT)


def tex_front(lit):
    rng = random.Random(3 if not lit else 4)
    img = stone(random.Random(3))
    front_common(img)
    for y in range(5, 14):
        for x in range(3, 13):
            if not lit:
                img.putpixel((x, y), hexc("#0E0C12"))
            else:
                t = (13 - y) / 8.0
                r = int(255 - 40 * t)
                g = int(215 - 150 * t)
                b = int(80 - 70 * t)
                if rng.random() < t * 0.45:
                    r, g, b = 40, 14, 8
                img.putpixel((x, y), (r, g, max(b, 0), 255))
    for x in (5, 8, 11):
        for y in range(5, 14):
            img.putpixel((x, y), GOLD_D if not lit else hexc("#3A1A08"))
    return img


# ----------------------------------------------------------------- icones
HELMET_PAL = {
    "o": hexc("#4A2E05"), "G": hexc("#FFD84A"), "H": hexc("#FFF3A8"), "g": hexc("#E8A914"),
    "d": hexc("#B87408"), "r": hexc("#D8531F"), "R": hexc("#A93A12"),
    "m": hexc("#2E2E36"), "M": hexc("#6B6B78"), "Y": hexc("#FFFFD0"), "y": hexc("#FFE766"),
}
HELMET_ROWS = [
    "........",
    "......oo",
    "....ooHG",
    "...oHGGG",
    "..oHGGmM",
    "..oGGGMy",
    ".oGGGGMY",
    ".oGGGgMy",
    ".oGGggmM",
    ".oGGgggg",
    "orrrrrrr",
    "oRRRRRRR",
    "oddddddd",
    ".ooooooo",
    "........",
    "........",
]
HELMET_SHADE = {"G": "g", "g": "d", "H": "G"}

BAG_PAL = {
    "o": hexc("#2E1B0B"), "B": hexc("#A9743A"), "b": hexc("#8B5A2B"), "d": hexc("#5E3A18"),
    "k": hexc("#F2C94C"), "K": hexc("#B8901E"),
}
BAG_ROWS = [
    "........",
    ".....ooo",
    "....oddd",
    "...oBBBB",
    "..oBBBBB",
    ".oBBBBBB",
    ".oBBBBBB",
    ".oddddkk",
    ".obbbbkK",
    ".obbbbkk",
    ".obbbbbb",
    ".obbbbbb",
    ".odbbbbb",
    "..oddddd",
    "....oooo",
    "........",
]
BAG_SHADE = {"B": "b", "b": "d"}


# ----------------------------------------------------------------- textura do capacete usado
def armor_layer1():
    img = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
    G, g, d = HELMET_PAL["G"], HELMET_PAL["g"], HELMET_PAL["d"]
    r, o = HELMET_PAL["r"], HELMET_PAL["o"]
    H = HELMET_PAL["H"]
    # topo da cabeca (8,0) 8x8
    rect(img, 8, 0, 8, 8, G)
    rect(img, 11, 0, 2, 8, r)
    for x in range(8, 16):
        img.putpixel((x, 0), H)
    # lados e frente: faixa de cima (4 linhas), resto transparente (mostra o rosto)
    for x0 in (0, 8, 16):  # direita, frente, esquerda
        rect(img, x0, 8, 8, 1, G)
        rect(img, x0, 9, 8, 1, r)
        rect(img, x0, 10, 8, 1, g)
        rect(img, x0, 11, 8, 1, d)
    # frente: aba escura sob a faixa
    for x in range(8, 16):
        img.putpixel((x, 11), o if x in (8, 15) else d)
    # costas (24,8): cobre um pouco mais
    rect(img, 24, 8, 8, 1, G)
    rect(img, 24, 9, 8, 1, r)
    rect(img, 24, 10, 8, 2, g)
    rect(img, 24, 12, 8, 1, d)

    # camada externa (hat, 32,0): LAMPADA na frente
    m, M = HELMET_PAL["m"], HELMET_PAL["M"]
    Y, y = HELMET_PAL["Y"], HELMET_PAL["y"]
    lamp = [
        "..mmmm..",
        ".MyYYyM.",
        ".MYYYYM.",
        "..mmmm..",
    ]
    pal = {"m": m, "M": M, "Y": Y, "y": y}
    for j, line in enumerate(lamp):
        for i, ch in enumerate(line):
            if ch != ".":
                img.putpixel((40 + i, 8 + j), pal[ch])
    # pequenos rebites dourados na lateral da camada externa
    for x0 in (32, 48):
        img.putpixel((x0 + 3, 9), GOLD_L)
        img.putpixel((x0 + 4, 9), GOLD_L)
    return img


def preview(imgs, path):
    scale = 10
    pad = 12
    W = pad
    H = 0
    scaled = []
    for im in imgs:
        s = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
        scaled.append(s)
        W += s.width + pad
        H = max(H, s.height)
    canvas = Image.new("RGBA", (W, H + pad * 2), (70, 90, 70, 255))
    x = pad
    for s in scaled:
        canvas.alpha_composite(s, (x, pad))
        x += s.width + pad
    canvas.save(path)


def head_front_composite(layer1):
    """Rosto simples + frente do capacete + lampada (visao de frente, 8x8)."""
    face = Image.new("RGBA", (8, 8), hexc("#C98E6A"))
    for x in (1, 2, 5, 6):
        face.putpixel((x, 4), hexc("#FFFFFF"))
    for x in (2, 5):
        face.putpixel((x, 4), hexc("#3355AA"))
    for x in range(8):
        face.putpixel((x, 0), hexc("#4A2B12"))
        face.putpixel((x, 1), hexc("#4A2B12"))
    front = layer1.crop((8, 8, 16, 16))
    hat = layer1.crop((40, 8, 48, 16))
    face.alpha_composite(front)
    face.alpha_composite(hat)
    return face


# ----------------------------------------------------------------- main
def main():
    preview_path = sys.argv[1] if len(sys.argv) > 1 else None

    # texturas de bloco
    side, top = tex_side(), tex_top()
    front_off, front_on = tex_front(False), tex_front(True)
    tb = os.path.join(ASSETS, "textures", "block")
    save(side, os.path.join(tb, "super_furnace_side.png"))
    save(top, os.path.join(tb, "super_furnace_top.png"))
    save(front_off, os.path.join(tb, "super_furnace_front.png"))
    save(front_on, os.path.join(tb, "super_furnace_front_on.png"))

    # icones
    helmet = from_halves(HELMET_ROWS, HELMET_PAL, HELMET_SHADE)
    bag = from_halves(BAG_ROWS, BAG_PAL, BAG_SHADE)
    ti = os.path.join(ASSETS, "textures", "item")
    save(helmet, os.path.join(ti, "light_helmet.png"))
    save(bag, os.path.join(ti, "portable_bag.png"))

    # armadura
    layer1 = armor_layer1()
    ta = os.path.join(ASSETS, "textures", "models", "armor")
    save(layer1, os.path.join(ta, "lamp_layer_1.png"))
    save(Image.new("RGBA", (64, 32), (0, 0, 0, 0)), os.path.join(ta, "lamp_layer_2.png"))

    # modelos de bloco
    def block_model(front_tex):
        return {
            "parent": "minecraft:block/orientable",
            "textures": {
                "top": f"{MOD}:block/super_furnace_top",
                "front": f"{MOD}:block/{front_tex}",
                "side": f"{MOD}:block/super_furnace_side",
            },
        }

    wjson(os.path.join(ASSETS, "models", "block", "super_furnace.json"), block_model("super_furnace_front"))
    wjson(os.path.join(ASSETS, "models", "block", "super_furnace_on.json"), block_model("super_furnace_front_on"))
    wjson(os.path.join(ASSETS, "models", "block", "light_source.json"),
          {"textures": {"particle": "minecraft:block/glowstone"}})

    # blockstates
    variants = {}
    for facing, rot in (("north", 0), ("east", 90), ("south", 180), ("west", 270)):
        for lit in ("false", "true"):
            model = f"{MOD}:block/super_furnace" + ("_on" if lit == "true" else "")
            v = {"model": model}
            if rot:
                v["y"] = rot
            variants[f"facing={facing},lit={lit}"] = v
    wjson(os.path.join(ASSETS, "blockstates", "super_furnace.json"), {"variants": variants})
    wjson(os.path.join(ASSETS, "blockstates", "light_source.json"),
          {"variants": {"waterlogged=false": {"model": f"{MOD}:block/light_source"},
                        "waterlogged=true": {"model": f"{MOD}:block/light_source"}}})

    # modelos de item
    wjson(os.path.join(ASSETS, "models", "item", "super_furnace.json"), {"parent": f"{MOD}:block/super_furnace"})
    for name in ("portable_bag", "light_helmet"):
        wjson(os.path.join(ASSETS, "models", "item", f"{name}.json"),
              {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/{name}"}})

    # traducoes
    pt = {
        "itemGroup.utilidades": "Utilidades Supremas",
        "block.utilidades.super_furnace": "Fornalha Suprema",
        "block.utilidades.light_source": "Luz do Capacete",
        "item.utilidades.portable_bag": "Bolsa Portátil",
        "item.utilidades.light_helmet": "Capacete de Iluminação",
        "tooltip.utilidades.bag_items": "Itens: %s/%s",
        "tooltip.utilidades.bag_hint": "Botão direito para abrir (também dentro do inventário)",
        "tooltip.utilidades.helmet": "Ilumina como uma tocha por onde você anda",
        "gui.utilidades.input": "Entrada",
        "gui.utilidades.output": "Saída",
    }
    en = {
        "itemGroup.utilidades": "Supreme Utilities",
        "block.utilidades.super_furnace": "Supreme Furnace",
        "block.utilidades.light_source": "Helmet Light",
        "item.utilidades.portable_bag": "Portable Bag",
        "item.utilidades.light_helmet": "Lighting Helmet",
        "tooltip.utilidades.bag_items": "Items: %s/%s",
        "tooltip.utilidades.bag_hint": "Right-click to open (also inside the inventory)",
        "tooltip.utilidades.helmet": "Lights up like a torch wherever you walk",
        "gui.utilidades.input": "Input",
        "gui.utilidades.output": "Output",
    }
    wjson(os.path.join(ASSETS, "lang", "pt_br.json"), pt)
    wjson(os.path.join(ASSETS, "lang", "en_us.json"), en)

    # receitas
    def item(i):
        return {"item": i}

    wjson(os.path.join(DATA, "recipes", "super_furnace.json"), {
        "type": "minecraft:crafting_shaped",
        "pattern": ["IGI", "BFS", "IHI"],
        "key": {
            "I": item("minecraft:iron_ingot"), "G": item("minecraft:gold_ingot"),
            "B": item("minecraft:blast_furnace"), "F": item("minecraft:furnace"),
            "S": item("minecraft:smoker"), "H": item("minecraft:hopper"),
        },
        "result": {"item": f"{MOD}:super_furnace"},
    })
    wjson(os.path.join(DATA, "recipes", "portable_bag.json"), {
        "type": "minecraft:crafting_shaped",
        "pattern": ["SLS", "LCL", "LLL"],
        "key": {"S": item("minecraft:string"), "L": item("minecraft:leather"), "C": item("minecraft:chest")},
        "result": {"item": f"{MOD}:portable_bag"},
    })
    wjson(os.path.join(DATA, "recipes", "light_helmet.json"), {
        "type": "minecraft:crafting_shaped",
        "pattern": ["GGG", "GLG"],
        "key": {"G": item("minecraft:gold_ingot"), "L": item("minecraft:lantern")},
        "result": {"item": f"{MOD}:light_helmet"},
    })

    # drop do bloco + ferramenta correta
    wjson(os.path.join(DATA, "loot_tables", "blocks", "super_furnace.json"), {
        "type": "minecraft:block",
        "pools": [{
            "rolls": 1.0,
            "bonus_rolls": 0.0,
            "entries": [{"type": "minecraft:item", "name": f"{MOD}:super_furnace"}],
            "conditions": [{"condition": "minecraft:survives_explosion"}],
        }],
    })
    wjson(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", "pickaxe.json"),
          {"replace": False, "values": [f"{MOD}:super_furnace"]})

    if preview_path:
        preview([helmet, bag, front_off, front_on, side, top], preview_path.replace(".png", "_icons.png"))
        preview([layer1, head_front_composite(layer1)], preview_path.replace(".png", "_armor.png"))
    print("recursos gerados em", ROOT)


if __name__ == "__main__":
    main()
